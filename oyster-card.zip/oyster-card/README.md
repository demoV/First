Please refer to the OysterCardTest for the given scenario of card use.

Run all test 
```bash
mvn clean test
```
