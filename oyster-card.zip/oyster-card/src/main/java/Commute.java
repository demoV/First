import java.util.Comparator;
import java.util.List;
import java.util.Set;

public class Commute {

    private Station startedAt;
    private Transport transport;
    private Station endAt;

    public Commute(Station startedAt, Transport transport) {
        this.startedAt = startedAt;
        this.transport = transport;
    }

    public Double getFareAmount() {
        if (transport.equals(Transport.BUS))
            return Fare.BUS.getAmount();
        if (endAt == null)
            return Fare.ZONE_MAX.getAmount();

        List<Set<Zone>> possibleZonesVisited = Zone.zonesFor(startedAt, endAt);
        return possibleZonesVisited.stream()
                .map(Fare::getFareFor)
                .min(Comparator.comparing(Fare::getAmount))
                .get()
                .getAmount();
    }

    public void endsAt(Station station) {
        this.endAt = station;
    }
}
