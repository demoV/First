public class Wallet {

    private Double balance;

    public Wallet(Double amount) {
        this.balance = amount;
    }


    public boolean debit(Double amount) {
        if (amount > this.balance)
            throw new LowBalanceException("Balance is Low");

        this.balance -= amount;
        return true;
    }

    public Double getBalance() {
        return balance;
    }
}
