

public enum Station {
    HOLBORN,
    ALDGATE,
    EARLS_COURT,
    HAMMERSMITH,
    ARSONAL,
    WIMBLEDON;
}
