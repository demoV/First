public enum Transport {
    TUBE, BUS
}
