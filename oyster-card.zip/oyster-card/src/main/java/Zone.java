import java.util.*;
import java.util.stream.Collectors;

public enum Zone {
    ONE("1", Set.of(Station.HOLBORN, Station.ALDGATE, Station.EARLS_COURT)),
    TWO("2", Set.of(Station.EARLS_COURT, Station.HAMMERSMITH, Station.ARSONAL)),
    THREE("3", Set.of(Station.WIMBLEDON));

    private final String id;
    private final Set<Station> stations;

    Zone(String id, Set<Station> stations) {
        this.id = id;
        this.stations = stations;
    }

    public String getId() {
        return id;
    }

    public static Set<Zone> zonesFor(Station station) {
        return Arrays.stream(values())
                .filter(zone -> zone.stations.contains(station))
                .collect(Collectors.toSet());
    }

    public static List<Set<Zone>> zonesFor(Station origin, Station destination) {
        ArrayList<Set<Zone>> zoneCombination = new ArrayList<>();
        for (Zone zone : zonesFor(origin)) {
            for (Zone other : zonesFor(destination)) {
                zoneCombination.add(new HashSet<>(Arrays.asList(zone, other)));
            }
        }
        return zoneCombination;
    }
}
