import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public enum Fare {
    ZONE_ONE("ZONE_1", 2.50),
    ZONE_TWO("ZONE_2", 2.0),
    ZONE_THREE("ZONE_3", 2.0),
    ZONE_ONE_TWO("ZONE_1_2", 3.0),
    ZONE_ONE_THREE("ZONE_1_3", 3.20),
    ZONE_TWO_THREE("ZONE_2_3", 2.25),
    ZONE_MAX("ZONE_1_2_3", 3.20),
    BUS("BUS_1", 1.80),
    NONE("NONE", 0.0);

    private final Double amount;
    private final String id;

    Fare(String id, Double amount) {
        this.id = id;
        this.amount = amount;
    }

    public static Fare getFareFor(Set<Zone> zonesVisited) {

        String fareId = "ZONE_" + zonesVisited.stream()
                .map(Zone::getId)
                .sorted()
                .collect(Collectors.joining("_"));
        return Arrays.stream(Fare.values())
                .filter(fare -> fare.id.equals(fareId))
                .findFirst()
                .orElse(Fare.NONE);
    }

    public Double getAmount() {
        return amount;
    }
}
