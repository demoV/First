public class OysterCard {

    private final Wallet wallet;
    private Commute commute;

    public OysterCard(Double initialAmount) {
        this.wallet = new Wallet(initialAmount);
    }

    public void swapIn(Station station, Transport transport) {
        this.commute = new Commute(station, transport);
    }

    public void swapOut(Station station) {
        commute.endsAt(station);
    }

    public void charge() {
        Double fareAmount = commute.getFareAmount();
        wallet.debit(fareAmount);
    }

    public Double getBalance() {
        return wallet.getBalance();
    }
}
