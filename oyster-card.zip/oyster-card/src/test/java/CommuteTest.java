import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommuteTest {

    @Test
    public void shouldGetMaxAmountIfJourneyHasNotEnded() {
        Commute commute = new Commute(Station.ARSONAL, Transport.TUBE);

        Double amount = commute.getFareAmount();
        Double expectedAmount = 3.20;

        assertEquals(expectedAmount, amount);
    }

    @Test
    public void shouldGetAmountForArsonalToWimbledon() {
        Commute commute = new Commute(Station.ARSONAL, Transport.TUBE);
        commute.endsAt(Station.WIMBLEDON);
        Double amount = commute.getFareAmount();
        Double expectedAmount = 2.25;

        assertEquals(expectedAmount, amount);
    }

    @Test
    public void shouldGetAmountForHolbornToAldgate() {
        Commute commute = new Commute(Station.HOLBORN, Transport.TUBE);
        commute.endsAt(Station.ALDGATE);
        Double amount = commute.getFareAmount();
        Double expectedAmount = 2.50;

        assertEquals(expectedAmount, amount);
    }

    @Test
    public void shouldGetAmountForArsonalToHammersmith() {
        Commute commute = new Commute(Station.ARSONAL, Transport.TUBE);
        commute.endsAt(Station.HAMMERSMITH);
        Double amount = commute.getFareAmount();
        Double expectedAmount = 2.0;

        assertEquals(expectedAmount, amount);
    }

    @Test
    public void shouldGetAmountForHammersmithToHolborn() {
        Commute commute = new Commute(Station.HAMMERSMITH, Transport.TUBE);
        commute.endsAt(Station.HOLBORN);
        Double amount = commute.getFareAmount();
        Double expectedAmount = 3.0;

        assertEquals(expectedAmount, amount);
    }

    @Test
    public void shouldGetAmountForWimbledonToAldgate() {
        Commute commute = new Commute(Station.WIMBLEDON, Transport.TUBE);
        commute.endsAt(Station.ALDGATE);
        Double amount = commute.getFareAmount();
        Double expectedAmount = 3.20;

        assertEquals(expectedAmount, amount);
    }

    @Test
    public void shouldGiveFlatFareForBus() {
        Commute commute = new Commute(Station.WIMBLEDON, Transport.BUS);

        assertEquals(1.80, commute.getFareAmount());

    }

}