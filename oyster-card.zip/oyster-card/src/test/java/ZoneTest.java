import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class ZoneTest {

    @Test
    public void shouldGiveZonesForGivenStation() {
        Set zones = Zone.zonesFor(Station.WIMBLEDON);

        Set<Zone> expectedZones = Set.of(Zone.THREE);
        assertEquals(expectedZones, zones);
    }

    @Test
    public void shouldGiveMultipleZonesForGivenStationIfApplicable() {
        Set zones = Zone.zonesFor(Station.EARLS_COURT);

        Set<Zone> expectedZones = Set.of(Zone.ONE, Zone.TWO);
        assertEquals(expectedZones, zones);
    }

    @Test
    public void shouldGiveZonesForGivenTwoStations() {
        List<Set<Zone>> zones = Zone.zonesFor(Station.EARLS_COURT, Station.WIMBLEDON);

        Set<Zone> zoneTwoAndThree = Set.of(Zone.TWO, Zone.THREE);
        Set<Zone> zoneOneAndThree = Set.of(Zone.ONE, Zone.THREE);
        List<Set<Zone>> expectedZones = Arrays.asList(zoneTwoAndThree, zoneOneAndThree);
        assertTrue(expectedZones.containsAll(zones));
        assertTrue(zones.containsAll(expectedZones));
    }

    @Test
    public void shouldGiveZoneCombinationForGivenTwoStations() {
        List<Set<Zone>> zones = Zone.zonesFor(Station.WIMBLEDON, Station.WIMBLEDON);

        Set<Zone> zoneThree = Set.of(Zone.THREE);
        List<Set<Zone>> expectedZones = Arrays.asList(zoneThree);
        assertEquals(expectedZones, zones);
    }
}