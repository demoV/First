import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OysterCardTest {

    @Test
    public void shouldChargeMaxAmountIfCardNotSwapOut() {

        OysterCard oysterCard = new OysterCard(30.0);
        oysterCard.swapIn(Station.HOLBORN, Transport.TUBE);

        oysterCard.charge();
        Double balance = oysterCard.getBalance();
        Double expectedBalance = 26.80;

        assertEquals(expectedBalance, balance);
    }

    @Test
    public void shouldChargeForTheJourney() {
        Double balance;
        Double expectedBalance;

        OysterCard oysterCard = new OysterCard(30.0);
        oysterCard.swapIn(Station.HOLBORN, Transport.TUBE);
        oysterCard.swapOut(Station.EARLS_COURT);

        oysterCard.charge();
        expectedBalance = 27.50;
        balance = oysterCard.getBalance();

        assertEquals(expectedBalance, balance);

        oysterCard.swapIn(Station.EARLS_COURT, Transport.BUS);
        oysterCard.charge();

        expectedBalance = 25.70;
        balance = oysterCard.getBalance();
        assertEquals(expectedBalance, balance);


        oysterCard.swapIn(Station.EARLS_COURT, Transport.TUBE);
        oysterCard.swapOut(Station.HAMMERSMITH);

        oysterCard.charge();
        expectedBalance = 23.70;
        balance = oysterCard.getBalance();
        assertEquals(expectedBalance, balance);

    }

}