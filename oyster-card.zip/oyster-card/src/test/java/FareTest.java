import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class FareTest {

    @Test
    public void shouldGiveFareForGivenZone() {
        Fare fare = Fare.getFareFor(Set.of(Zone.ONE));

        assertEquals(Fare.ZONE_ONE, fare);
    }

    @Test
    public void shouldGiveFareForGivenZones() {
        Fare fare = Fare.getFareFor(Set.of(Zone.ONE, Zone.TWO));

        assertEquals(Fare.ZONE_ONE_TWO, fare);
    }

}