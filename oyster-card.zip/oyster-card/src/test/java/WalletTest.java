import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WalletTest {

    @Test
    public void shouldDebitTheAmount() {
        Wallet wallet = new Wallet(10.0);

        assertTrue(wallet.debit(2.0));
    }

    @Test
    public void shouldThrowLowBalanceExceptionIfDebitAmountIsGreaterThanBalance() {
        Wallet wallet = new Wallet(5.0);

        assertThrows(LowBalanceException.class, () -> wallet.debit(5.20));
    }
}